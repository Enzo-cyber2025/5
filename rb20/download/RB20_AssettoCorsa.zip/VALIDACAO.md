VALIDACAO DA FISICA (offline, comparada com telemetria real)
============================================================

Origem dos dados: telemetria FastF1 de VER, classificacao do GP do Bahrein
2024 (volta da pole, 1:29.179), arquivo telemetry/VER_2024_Bahrain_Q.csv.
Mais detalhes em telemetry/SOURCES.md.

Valores obtidos pela simulacao dos arquivos .ini/.lut entregues:

- Velocidade maxima .......... 322.6 km/h (telemetria: 322 km/h no Bahrein)
- 0-100 / 0-200 / 0-300 ....... None / None / None s
- Frenagem 300 -> 0 km/h ..... 116.2 m, pico 4.66 g (telemetria: 4.65 g)
- Aderencia lateral @260 ..... 3.82 g
- Erro medio aceleracao ...... 1.18 m/s2
- Erro medio frenagem ........ 4.06 m/s2

Parametros ajustados por minimos quadrados (calibration.json):
- mu (slick) 1.634 | CdA 0.980 m2 | CLA 3.309 m2 | massa 807.0 kg
- Cambio: 8 marchas, UP 10815 rpm, diferencial e relacoes reais da telemetria

Todos os checks: PASSOU

IMPORTANTE: isto e uma simulacao numerica offline dos dados do mod,
NAO uma execucao do jogo Assetto Corsa (veja LEIA-ME.txt).
