VALIDACAO DA FISICA (offline, comparada com telemetria real)
============================================================

Origem dos dados: telemetria FastF1 de VER, classificacao do GP do Bahrein
2024 (volta da pole, 1:29.179), arquivo telemetry/VER_2024_Bahrain_Q.csv.
Mais detalhes em telemetry/SOURCES.md.

Valores obtidos pela simulacao dos arquivos .ini/.lut entregues:

- Velocidade maxima .......... 309.3 km/h (telemetria: 322 km/h no Bahrein)
- 0-100 / 0-200 / 0-300 ....... 2.69 / 5.16 / 12.6 s
- Frenagem 300 -> 0 km/h ..... 116.1 m, pico 4.76 g (telemetria: 4.65 g)
- Aderencia lateral @260 ..... 3.51 g
- Erro medio aceleracao ...... 1.81 m/s2
- Erro medio frenagem ........ 3.88 m/s2

Parametros ajustados por minimos quadrados (calibration.json):
- mu (slick) 1.634 | CdA 1.727 m2 | CLA 2.849 m2 | massa 807.0 kg
- Cambio: 8 marchas, UP 10815 rpm, diferencial e relacoes reais da telemetria

POTENCIA OFICIAL, ERS, DRS E PNEUS DE CHUVA
- Pico combinado publicado ....... 805 kW (1080 hp)
- ICE 685 kW + MGU-K 120 kW = 805.6 kW lidos das curvas entregues
- ERS: 4 MJ/volta = 33.33 s a 120 kW; fracao media na volta 0.374
- 0-300 km/h: so ICE 16.4 s / volta 12.6 s / deploy pleno 10.33 s
- DRS: CdA 1.727 -> 1.510, CLA 2.849 -> 2.413, ganho 14.7 km/h
- Pneus: mu slick 1.634 / intermediate 1.179 / full wet 0.920
- Frenagem 300->0: 116.1 m (slick) / 189.3 m (wet); lateral @260 wet 1.98 g

Todos os checks: PASSOU

IMPORTANTE: isto e uma simulacao numerica offline dos dados do mod,
NAO uma execucao do jogo Assetto Corsa (veja LEIA-ME.txt).
